import tkinter as tk
from tkinter import messagebox
import random, string, base64
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP

def generate_otp():
    upper = random.choices(string.ascii_uppercase, k=2)
    special = random.choices("@#$%&*!?", k=2)
    others = random.choices(string.ascii_lowercase + string.digits, k=2)
    otp_chars = upper + special + others
    random.shuffle(otp_chars)
    return ''.join(otp_chars)

def encrypt_otp(otp, public_key_data):
    public_key = RSA.import_key(public_key_data)
    cipher = PKCS1_OAEP.new(public_key)
    encrypted = cipher.encrypt(otp.encode())
    return base64.b64encode(encrypted)

def decrypt_otp(encrypted_otp, private_key_data):
    private_key = RSA.import_key(private_key_data)
    cipher = PKCS1_OAEP.new(private_key)
    decrypted = cipher.decrypt(base64.b64decode(encrypted_otp))
    return decrypted.decode()

def run_otp_process():
    otp = generate_otp()
    private_key, public_key = RSA.generate(2048).export_key(), None
    key = RSA.import_key(private_key)
    public_key = key.publickey().export_key()

    encrypted = encrypt_otp(otp, public_key)
    decrypted = decrypt_otp(encrypted, private_key)

    result = f"OTP: {otp}\nEncrypted: {encrypted.decode()}\nDecrypted: {decrypted}"
    messagebox.showinfo("OTP Result", result)

app = tk.Tk()
app.title("OTP Generator + Encryptor")
app.geometry("400x200")

label = tk.Label(app, text="🔐 Click below to generate secure OTP", font=("Arial", 12))
label.pack(pady=20)

btn = tk.Button(app, text="Generate OTP", command=run_otp_process, bg="black", fg="white", font=("Arial", 12, "bold"))
btn.pack()

app.mainloop()

import argparse, random, string, base64
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP

def generate_otp():
    upper = random.choices(string.ascii_uppercase, k=2)
    special = random.choices("@#$%&*!?", k=2)
    others = random.choices(string.ascii_lowercase + string.digits, k=2)
    otp_chars = upper + special + others
    random.shuffle(otp_chars)
    return ''.join(otp_chars)

def encrypt_otp(otp, public_key_data):
    public_key = RSA.import_key(public_key_data)
    cipher = PKCS1_OAEP.new(public_key)
    encrypted = cipher.encrypt(otp.encode())
    return base64.b64encode(encrypted)

def decrypt_otp(encrypted_otp, private_key_data):
    private_key = RSA.import_key(private_key_data)
    cipher = PKCS1_OAEP.new(private_key)
    decrypted = cipher.decrypt(base64.b64decode(encrypted_otp))
    return decrypted.decode()

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="🔐 Secure OTP Generator & Encryptor")
    parser.add_argument("--decrypt", help="Decrypt a given encrypted OTP", type=str)
    args = parser.parse_args()

    if args.decrypt:
        print("🔓 Decryption requires private key — not implemented in CLI for security.")
    else:
        otp = generate_otp()
        private_key = RSA.generate(2048)
        priv = private_key.export_key()
        pub = private_key.publickey().export_key()

        encrypted = encrypt_otp(otp, pub)
        decrypted = decrypt_otp(encrypted, priv)

        print(f"✅ OTP: {otp}")
        print(f"🔐 Encrypted (base64): {encrypted.decode()}")
        print(f"🔓 Decrypted: {decrypted}")

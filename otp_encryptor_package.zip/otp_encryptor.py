import random
import string
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
import base64

def generate_otp():
    upper = random.choices(string.ascii_uppercase, k=2)
    special = random.choices("@#$%&*!?", k=2)
    others = random.choices(string.ascii_lowercase + string.digits, k=2)
    otp_chars = upper + special + others
    random.shuffle(otp_chars)
    return ''.join(otp_chars)

def generate_rsa_keys():
    key = RSA.generate(2048)
    private_key = key.export_key()
    public_key = key.publickey().export_key()
    return private_key, public_key

def encrypt_otp(otp, public_key_data):
    public_key = RSA.import_key(public_key_data)
    cipher = PKCS1_OAEP.new(public_key)
    encrypted = cipher.encrypt(otp.encode())
    return base64.b64encode(encrypted)

def decrypt_otp(encrypted_otp, private_key_data):
    private_key = RSA.import_key(private_key_data)
    cipher = PKCS1_OAEP.new(private_key)
    decrypted = cipher.decrypt(base64.b64decode(encrypted_otp))
    return decrypted.decode()

otp = generate_otp()
private_key, public_key = generate_rsa_keys()
encrypted_otp = encrypt_otp(otp, public_key)
decrypted_otp = decrypt_otp(encrypted_otp, private_key)

print(f"🔐 Generated OTP      : {otp}")
print(f"🔒 Encrypted OTP (Base64): {encrypted_otp.decode()}")
print(f"🔓 Decrypted OTP      : {decrypted_otp}")
